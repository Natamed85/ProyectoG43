insert into Empleado values('1', 'Martha', 'Cáceres', '345435', 'Cra 8 No. 7A-24');
insert into Empleado values('2', 'Mercedes', 'Noguera', '4454', 'Cra 7A No. 6-24');
insert into Empleado values('3', 'Hernán', 'Moreno', '345345', 'Favuis');
insert into Empleado values('4', 'Jorge', 'Granados', '67567', 'Los Cerros');
insert into Empleado values('5', 'César', 'Tejada', '345345', 'Las Lomas');
insert into Empleado values('6', 'Eleazar', 'Judía', '678678', 'El Prado');