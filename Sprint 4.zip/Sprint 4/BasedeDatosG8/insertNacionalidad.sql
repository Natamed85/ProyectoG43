insert Nacionalidad values('1', 'Estadounidense');
insert Nacionalidad values('2', 'Colombiano');
insert Nacionalidad values('3', 'Español');
insert Nacionalidad values('4', 'Chino');
insert Nacionalidad values('5', 'Japonés');
insert Nacionalidad values('6', 'Alemán');