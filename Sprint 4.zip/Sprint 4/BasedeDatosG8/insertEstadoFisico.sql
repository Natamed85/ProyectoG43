insert into EstadoFisico values('1', 'Nuevo');
insert into EstadoFisico values('2', 'Buen estado');
insert into EstadoFisico values('3', 'Por reparar');
insert into EstadoFisico values('4', 'Dado de baja');