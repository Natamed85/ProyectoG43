select l.nombre_lib, p.numero_pres, p.fecha_pres
from Tema t
inner join tema_libro tl on t.codigo_tem=tl.codigo_tem
inner join Libro l on l.codigo_lib=tl.codigo_lib
inner join reserva r on l.codigo_lib=r.codigo_lib
inner join Prestamo p on p.numero_res=r.numero_res
where t.nombre_tema='Matemáticas'
order by l.nombre_lib desc;

