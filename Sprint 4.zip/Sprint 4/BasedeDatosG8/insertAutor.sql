insert Autor values('1', 'Juan Perez', 'M');
insert Autor values('2', 'Pedro Muñoz', 'M');
insert Autor values ('3', 'Jessica Pachecho', 'F');
insert Autor values('4', 'Santiago Muñoz', 'M');
insert Autor values('5', 'Mariana Muñoz', 'F');
insert Autor values('6', 'Ambar Medina', 'F');
insert Autor values('7', 'Paula Martínez', 'F');
insert Autor values('8', 'Luisa López', 'F');