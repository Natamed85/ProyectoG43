create database biblioteca_g51;
use biblioteca_g51;
create table Tema(
codigo_tem varchar(15) not null,
nombre_tema varchar(50) not null,
constraint tema_pk primary key(codigo_tem));
create table Editorial(
codigo_edi varchar(15) not null,
nombre_edi varchar(50) not null,
constraint Editorial_pk primary key(codigo_edi));
create table Idioma(
codigo_idi varchar(15) not null,
nombre_idi varchar(50) not null,
constraint Idioma_pk primary key(codigo_idi));
create table EstadoFisico(
codigo_estFis varchar(15) not null,
nombre_estFis varchar(50) not null,
constraint estadoFisico_pk primary key(codigo_estFis));
create table Libro(
codigo_lib varchar(15) not null,
nombre_lib varchar(50) not null,
disp_lib varchar(15) not null,
codigo_edi varchar(15) not null,
codigo_idi varchar(15) not null,
codigo_estFis varchar(15) not null,
constraint libro_pk primary key(codigo_lib),
constraint codigo_edi_fk foreign key(codigo_edi) references Editorial(codigo_edi),
constraint codigo_idi_fk foreign key(codigo_idi) references Idioma(codigo_idi),
constraint codigo_estFis_fk foreign key(codigo_estFis) references EstadoFisico(codigo_estFis),
constraint Libro_disp_ck check(disp_lib='Si' or disp_lib='No'));
create table tema_libro(
codigo_tem varchar(15) not null,
codigo_lib varchar(15) not null,
constraint tema_libro_pk primary key(codigo_tem,codigo_lib),
constraint tema_libro_codigo_tem_fk foreign key(codigo_tem) references Tema(codigo_tem),
constraint tema_libro_codigo_lib_fk foreign key(codigo_lib) references Libro(codigo_lib));
create table Nacionalidad(
codigo_nac varchar(15) not null,
nombre_nac varchar(50) not null,
constraint Nacionalidad_pk primary key(codigo_nac));
create table Autor(
codigo_aut varchar(15) not null,
nombre_aut varchar(50) not null,
genero_aut varchar(1) not null,
constraint Autor_pk primary key(codigo_aut),
constraint Autor_genero_aut_ck check(genero_aut='M' or genero_aut='F'));
create table autor_nacionalidad(
codigo_aut varchar(15) not null,
codigo_nac varchar(15) not null,
constraint autor_nacionalidad_pk primary key(codigo_aut,codigo_nac),
constraint autor_nacionalidad_codigo_aut_fk foreign key(codigo_aut) references Autor(codigo_aut),
constraint autor_nacionalidad_codigo_nac_fk foreign key(codigo_nac) references Nacionalidad(codigo_nac));
create table libro_autor(
codigo_lib varchar(15) not null,
codigo_aut varchar(15) not null,
constraint libro_autor_pk primary key(codigo_lib,codigo_aut),
constraint libro_autor_codigo_lib_fk foreign key(codigo_lib) references Libro(codigo_lib),
constraint libro_autor_codigo_aut_fk foreign key(codigo_aut) references Autor(codigo_aut));
create table Estudiante(
codigo_estud varchar(15) not null,
nombre_estud varchar(50) not null,
apellido_estud varchar(50) not null,
tel_estud varchar(15) not null,
dir_estud varchar(50) not null,
constraint Estudiante_codigo_estud_pk primary key(codigo_estud));
create table reserva(
numero_res varchar(15) not null,
fecha_res date not null,
codigo_lib varchar(15) not null,
codigo_estud varchar(15) not null,
constraint reserva_numero_res_pk primary key(numero_res),
constraint reserva_codigo_lib_fk foreign key(codigo_lib) references Libro(codigo_lib),
constraint reserva_codigo_estud_fk foreign key(codigo_estud) references Estudiante(codigo_estud));
create table Empleado(
codigo_empl varchar(15) not null,
nombre_empl varchar(50) not null,
apellido_empl varchar(50) not null,
tel_empl varchar(15) not null,
dir_empl varchar(50) not null,
constraint Empleado_codigo_empl_pk primary key(codigo_empl));
create table Prestamo(
numero_pres varchar(15) not null,
fecha_pres date not null,
fecha_ent_indic date not null,
fecha_ent_real date,
valor_multa double,
numero_res varchar(15) not null,
codigo_empl varchar(15) not null,
codigo_estud varchar(15) not null,
constraint Prestamo_numero_pres_pk primary key(numero_pres),
constraint Prestamo_numero_res_fk foreign key(numero_res) references reserva(numero_res),
constraint Prestamo_codigo_empl_fk foreign key(codigo_empl) references Empleado(codigo_empl),
constraint Prestamo_codigo_estud_fk foreign key(codigo_estud) references Estudiante(codigo_estud));
