
package restful.resource;
import java.util.ArrayList;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import restful.Model.EstudianteModel;
import restful.service.EstudianteService;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;


@Path("estudiante")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class EstudianteResource {
   
    EstudianteService servicio=new EstudianteService();

    @GET
    public ArrayList<EstudianteModel> getEstudiantes() {

        return servicio.getEstudiantes();
    }
    
    @Path("/{Codigo_estud}")
    @GET
    public EstudianteModel getEstudiante(@PathParam("Codigo_estud") String codigo_estud) {

        return servicio.getEstudiante(codigo_estud);
    }
    
    @POST
    public EstudianteModel addEstudiante(String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        EstudianteModel estudiante = gson.fromJson(JSON, EstudianteModel.class);
        return servicio.addEstudiante(estudiante);
    }
    
    @PUT
    public EstudianteModel updateEstudiante(String JSON) {
        GsonBuilder builder = new GsonBuilder();
        builder.setPrettyPrinting();
        Gson gson = builder.create();
        EstudianteModel estudiante = gson.fromJson(JSON, EstudianteModel.class);
        return servicio.updateEstudiante(estudiante);
    }
    
    @DELETE
    @Path("/{Codigo_estud}")
    public String delEstudiante(@PathParam("Codigo_estud") String codigo_estud) {

        return servicio.delEstudiante(codigo_estud);

    }
    
}
