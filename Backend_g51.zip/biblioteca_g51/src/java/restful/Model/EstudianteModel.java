
package restful.Model;

import java.util.ArrayList;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class EstudianteModel {
    private String codigo_estud;
    private String nombre_estud;
    private String apellido_estud;
    private String tel_estud;
    private String dir_estud;
    
    public EstudianteModel() {
    }

    public EstudianteModel(String codigo_estud, String nombre_estud, String apellido_estud, String tel_estud, String dir_estud) {
        this.codigo_estud = codigo_estud;
        this.nombre_estud = nombre_estud;
        this.apellido_estud = apellido_estud;
        this.tel_estud = tel_estud;
        this.dir_estud = dir_estud;
    }

    public String getCodigo_estud() {
        return codigo_estud;
    }

    public void setCodigo_estud(String codigo_estud) {
        this.codigo_estud = codigo_estud;
    }

    public String getNombre_estud() {
        return nombre_estud;
    }

    public void setNombre_estud(String nombre_estud) {
        this.nombre_estud = nombre_estud;
    }

    public String getApellido_estud() {
        return apellido_estud;
    }

    public void setApellido_estud(String apellido_estud) {
        this.apellido_estud = apellido_estud;
    }

    public String getTel_estud() {
        return tel_estud;
    }

    public void setTel_estud(String tel_estud) {
        this.tel_estud = tel_estud;
    }

    public String getDir_estud() {
        return dir_estud;
    }

    public void setDir_estud(String dir_estud) {
        this.dir_estud = dir_estud;
    }

    
    
}
