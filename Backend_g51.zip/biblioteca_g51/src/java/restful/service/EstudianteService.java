
package restful.service;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.util.ArrayList;
import restful.Model.EstudianteModel;
import restful.Model.Conexion;


public class EstudianteService {
    
    public ArrayList<EstudianteModel> getEstudiantes() {
        ArrayList<EstudianteModel> lista = new ArrayList<>();
        Conexion conn = new Conexion();
        String sql = "SELECT * FROM estudiante";

        try {
            Statement stm = conn.getCon().createStatement();
            ResultSet rs = stm.executeQuery(sql);
            while (rs.next()) {
                //Crear un objeto de la clase estudiante
                EstudianteModel estudiante=new EstudianteModel();
                
                estudiante.setCodigo_estud(rs.getString("codigo_estud"));
                estudiante.setNombre_estud(rs.getString("nombre_estud"));
                estudiante.setApellido_estud(rs.getString("apellido_estud"));
                estudiante.setTel_estud(rs.getString("tel_estud"));
                estudiante.setDir_estud(rs.getString("dir_estud"));
                
                //Agrgar objeto al arreglo de objetos
                lista.add(estudiante);
            }
        }catch (SQLException e) {
        }

        return lista;
    }
    
     
    public EstudianteModel getEstudiante(String codigo_estud) {
         
        EstudianteModel estudiante=new EstudianteModel();

        Conexion conex = new Conexion();
        String Sql = "SELECT * FROM estudiante WHERE codigo_estud = ?";

        try {

            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setString(1, codigo_estud);
            
            ResultSet rs = pstm.executeQuery();

            while (rs.next()) {
                //Crear el objeto
                estudiante.setCodigo_estud(rs.getString("codigo_estud"));
                estudiante.setNombre_estud(rs.getString("nombre_estud"));
                estudiante.setApellido_estud(rs.getString("apellido_estud"));
                estudiante.setTel_estud(rs.getString("tel_estud"));
                estudiante.setDir_estud(rs.getString("dir_estud"));

                
            }
        } catch (SQLException e) {
            System.out.println(e);
        }

        return estudiante;
    }

    public EstudianteModel addEstudiante(EstudianteModel estudiante) {
        Conexion conex = new Conexion();
        String Sql = "INSERT INTO estudiante(codigo_estud,nombre_estud,apellido_estud,tel_estud,dir_estud)";
        Sql = Sql + "values (?,?,?,?,?)";

        try {
            PreparedStatement pstm = conex.getCon().prepareStatement(Sql);
            pstm.setString(1, estudiante.getCodigo_estud());
            pstm.setString(2, estudiante.getNombre_estud());
            pstm.setString(3, estudiante.getApellido_estud());
            pstm.setString(4, estudiante.getTel_estud());
            pstm.setString(5, estudiante.getDir_estud());
            pstm.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e);
            return null;
        }
        return estudiante;
    }
    
    public EstudianteModel updateEstudiante(EstudianteModel estudiante) {
        Conexion conn = new Conexion();
        String sql = "UPDATE estudiante SET nombre_estud=?,apellido_estud=?,tel_estud=?,dir_estud=? WHERE codigo_estud= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setString(1, estudiante.getNombre_estud());
            pstm.setString(2, estudiante.getApellido_estud());
            pstm.setString(3, estudiante.getTel_estud());
            pstm.setString(4, estudiante.getDir_estud());
            pstm.setString(5, estudiante.getCodigo_estud());
           
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al modificar  " + excepcion.getMessage());
            return null;
        }
        return estudiante;
    }
    
    public String delEstudiante(String codigo_estud) {
        Conexion conn = new Conexion();

        String sql = "DELETE FROM estudiante WHERE codigo_estud= ?";
        try {
            PreparedStatement pstm = conn.getCon().prepareStatement(sql);
            pstm.setString(1, codigo_estud);
            
            pstm.executeUpdate();
        } catch (SQLException excepcion) {
            System.out.println("Ha ocurrido un error al eliminar  " + excepcion.getMessage());
            return "{\"Accion\":\"Error\"}";
        }
        return "{\"Accion\":\"Registro Borrado\"}";
    }
}
