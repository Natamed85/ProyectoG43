const url = "http://localhost:8080/biblioteca_g51/api/estudiante"
const contenedor = document.querySelector('tbody')

let resultados = ''
const modalEstudiante = new bootstrap.Modal(document.getElementById('modalEstudiante'))
const formEstudiante = document.querySelector('form')
const idEstudiante = document.getElementById('id')
const nombreEstudiante = document.getElementById('nombre')
const apellidoEstudiante = document.getElementById('apellido')
const direccionEstudiante = document.getElementById('direccion')
const telefonoEstudiante = document.getElementById('telefono')


let opcion = ''
btnCrear.addEventListener('click', () => {
    
    idEstudiante.value = ''
    idEstudiante.disabled = false
    nombreEstudiante.value = ''
    apellidoEstudiante.value = ''
    direccionEstudiante.value = ''
    telefonoEstudiante.value = ''
    modalEstudiante.show()
    opcion = 'crear'
})
const ajax = (options) => {
    let { url, method, success, error, data } = options;
    const xhr = new XMLHttpRequest();

    xhr.addEventListener("readystatechange", (e) => {
        if (xhr.readyState !== 4) return;

        if (xhr.status >= 200 && xhr.status < 300) {
            let json = JSON.parse(xhr.responseText);
            success(json);
        } else {
            let message = xhr.statusText || "Ocurrió un error";
            error(`Error ${xhr.status}: ${message}`);
        }
    });

    xhr.open(method || "GET", url);
    xhr.setRequestHeader("Content-type", "application/json; charset=utf-8");
    xhr.send(JSON.stringify(data));
};
const getAll = () => {
    ajax({
        url: url,
        method: "GET",
        success: (res) => {
            console.log(res);

            res.forEach((estudiante) => {
                resultados += `<tr>
                        <td width="10%">${estudiante.codigo_estud}</td>
                        <td width="20%">${estudiante.nombre_estud}</td>
                        <td width="20%">${estudiante.apellido_estud}</td>
                        <td width="20%">${estudiante.dir_estud}</td>
                        <td width="15%">${estudiante.tel_estud}</td>
                        <td class="text-center" width="15%"><a class="btnEditar btn btn-primary">Editar</a><a class="btnBorrar btn btn-danger">Borrar</a></td>
                    </tr>`
            });

            contenedor.innerHTML = resultados
        },
        error: (err) => {
            console.log(err);
            $table.insertAdjacentHTML("afterend", `<p><b>${err}</b></p>`);
        },
    });
};
document.addEventListener("DOMContentLoaded", getAll);
document.addEventListener("click", (e) => {

    if (e.target.matches(".btnBorrar")) {
        const fila = e.target.parentNode.parentNode
        const id = fila.firstElementChild.innerHTML
        console.log(id)
        alertify.confirm(`¿Estás seguro de eliminar el id ${id}?`,
            function () {
                ajax({
                    url: url + "/" + id,
                    method: "DELETE",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    success: (res) => location.reload(),
                    error: (err) => alert(err),
                });
                alertify.success('Registro eliminado')
            },
            function () {
                alertify.error('Cancel')
            });


    }
    if (e.target.matches(".btnEditar")) {
        const fila = e.target.parentNode.parentNode
        idEstudiante.value = fila.children[0].innerHTML
        nombreEstudiante.value = fila.children[1].innerHTML
        apellidoEstudiante.value = fila.children[2].innerHTML
        direccionEstudiante.value = fila.children[3].innerHTML
        telefonoEstudiante.value = fila.children[4].innerHTML
        idEstudiante.disabled = true
        opcion = 'editar'
        modalEstudiante.show()
    }
})

formEstudiante.addEventListener('submit', (e) => {
    e.preventDefault()
    let metodo = "POST"
    if (opcion == 'editar') {
        metodo = "PUT"
 
    }
    ajax({
        url: url,
        method: metodo,
        headers: {
            'Content-Type': 'application/json'
        },
        success: (res) => location.reload(),
        error: (err) =>
            $form.insertAdjacentHTML("afterend", `<p><b>${err}</b></p>`),
        data: {
            "apellido_estud": apellidoEstudiante.value,
            "codigo_estud": idEstudiante.value,
            "dir_estud": direccionEstudiante.value,
            "nombre_estud": nombreEstudiante.value,
            "tel_estud": telefonoEstudiante.value
        },
    });
    modalEstudiante.hide()
})
