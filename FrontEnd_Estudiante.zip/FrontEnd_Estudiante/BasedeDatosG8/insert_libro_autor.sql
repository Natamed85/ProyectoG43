insert into libro_autor values('1', '1');
insert into libro_autor values('2', '2');
insert into libro_autor values('3', '3');
insert into libro_autor values('4', '4');
insert into libro_autor values('5', '5');
insert into libro_autor values('6', '5');
insert into libro_autor values('7', '4');
