insert into Libro values('1', 'Algebra Baldor', 'Si', '1', '1', '2');
insert into Libro values('2', 'Cálculo', 'Si', '1', '1', '2');
insert into Libro values('3', 'Windows Básico', 'Si', '1', '1', '2');
insert into Libro values('4', 'Metodología de la Programación', 'Si', '1', '1', '2');
insert into Libro values('5', 'Lengua Castellana', 'Si', '2', '1', '2');
insert into Libro values('6', 'Nacho Lee', 'Si', '2', '1', '2');
insert into Libro values('7', 'Biología Integral', 'Si', '3', '1', '2');