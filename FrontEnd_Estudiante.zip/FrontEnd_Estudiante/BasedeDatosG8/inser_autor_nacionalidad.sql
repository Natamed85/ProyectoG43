insert into autor_nacionalidad values('1', '1');
insert into autor_nacionalidad values('2', '2');
insert into autor_nacionalidad values('3', '3');
insert into autor_nacionalidad values('4', '4');
insert into autor_nacionalidad values('5', '5');