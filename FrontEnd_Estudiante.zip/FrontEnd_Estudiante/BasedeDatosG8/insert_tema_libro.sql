insert into tema_libro values('1', '1');
insert into tema_libro values('1', '2');
insert into tema_libro values('3', '3');
insert into tema_libro values('3', '4');
insert into tema_libro values('2', '2');
insert into tema_libro values('2', '6');
insert into tema_libro values('4', '7');
insert into tema_libro values('4', '6');