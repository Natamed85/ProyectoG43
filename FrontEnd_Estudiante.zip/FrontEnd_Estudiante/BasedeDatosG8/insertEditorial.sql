insert into editorial values('1', 'MCGRAW HILL');
insert into editorial values('2', 'PRENTICE HALL');
insert into editorial values('3', 'ALFA OMEGA');
insert into editorial values('4', 'MCGRAW HILL');