select e.nombre_estud,p.numero_pres,p.fecha_pres,p.valor_multa
from Estudiante e
inner join reserva r on e.codigo_estud=r.codigo_estud
inner join Prestamo p on r.numero_res=p.numero_res 
where p.valor_multa between 1000 and 5000
order by p.valor_multa desc;