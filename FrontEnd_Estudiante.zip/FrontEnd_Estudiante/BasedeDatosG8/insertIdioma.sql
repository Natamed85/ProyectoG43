insert into Idioma values('1', 'Español');
insert into Idioma values('2', 'Inglés');
insert into Idioma values('3', 'Mandarín');
insert into Idioma values('4', 'Francés');
insert into Idioma values('5', 'Alemán');
insert into Idioma values('6', 'Italiano');