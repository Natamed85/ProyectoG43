insert into Tema values('1', 'Matemáticas');
insert into Tema values('2', 'espeañol');
insert into Tema values('3', 'Informática');
insert into Tema values('4', 'Biología');
insert into Tema values('5', 'Anatomía');
insert into Tema values('6', 'Programación');